import React from 'react';
import {
    View,
    Text,
    Image
} from 'react-native';
import { Colors } from 'react-native/Libraries/NewAppScreen';
import { FONTS, COLORS, icons } from '../constants';
 
const TabIcon  = ({focused, icon, iconStyle, label, isTrade})=>{

    if(isTrade)
    {
        return(
            <View style={{
                alignItems:'center',
                justifyContent:'center',
                height:60,
                width:60,
                borderRadius:29,
                backgroundColor:Colors.black
                }}>
                    <Image
                    source={icon}
                    resizeMode='contain'
                    style={{
                        width:25,
                        height:25,
                        tintColor:Colors.white,
                        ...iconStyle
                    }}

                    />
                   
                <Text style={{color:COLORS.white,...FONTS.h4}}>
                    Wallet
                </Text>
            </View>

        )
    }
    else{

        return(
            <View style={{alignItems:'center',justifyContent:'center'}}>
                <Image
                    source={icon}
                    resizeMode="contain"
                    style={{
                        width:25,
                        height:25,
                        tintColor:focused?COLORS.red:COLORS.black,
                        ...iconStyle
                    }}
                    onPress = {() => {}}
                >
                </Image>
                <Text
                style={{
                    color:focused?COLORS.red:COLORS.black,
                    ...FONTS.h4
                }}
                >
                    {label}
                </Text>

        </View>

        )
    }
    return(
        <View>
            <Text>Tab</Text>
        </View>
    )
}
export default TabIcon;