export const red="#D90000";
export const grey="#E4E4E4";
export const pink="#F7CCCC";
