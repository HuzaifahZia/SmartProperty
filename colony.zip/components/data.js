export default[
    {
      title: "Model Town Lahore Block k house 33",
      body: "Rs/-400,000,000. The House is a 3 bedroom, 3 bathroom with a private garage and a patio.",
      imgUrl: "https://picsum.photos/id/11/200/300"
    },
    {
      title: "Faisal Town Block A House",
      body: "Rs/-100,000,000. The House is a 3 bedroom, 3 bathroom with a private garage and a patio. ",
      imgUrl: "https://picsum.photos/id/10/200/300"
    },
    {
      title: "Beach House",
      body: " Rs/-200,000,000. The House is a 3 bedroom, 3 bathroom with a private garage and a patio.",
      imgUrl: "https://picsum.photos/id/12/200/300"
    },
    {
        title: "New Murree house#12",
        body: " Rs/-2000,000. The House is a 2 bedroom, 2 bathroom and a patio.",
        imgUrl: "https://picsum.photos/id/12/200/300"
    },
    {
        title: "Gulberge 2 House 10P",
        body: " For Rent Rs-/ 200,000 per month.",
        imgUrl: "https://picsum.photos/id/12/200/300"
    },
    {
        title: "Peshawar Hyatabad Main district Plot 103",
        body: " Rs-/6000,000 Prime Commertial plot for sale",
        imgUrl: "https://picsum.photos/id/12/200/300"
    }
  ]