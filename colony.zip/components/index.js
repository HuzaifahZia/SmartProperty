import TabIcon from "./TabIcon";

export{

    TabIcon

}