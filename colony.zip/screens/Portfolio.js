import React from 'react';
import {
    View,
    Text
} from 'react-native';
import { COLORS } from '../constants';

const Portfolio = () => {
    return (
 
 
 <View/>
        )
}

export default Portfolio;