import React ,{ useEffect, useRef, useState }from 'react';
import {View,Dimensions,Text,TouchableHighlight,ActivityIndicator,TextInput,TouchableOpacity,Image, ScrollView} from "react-native";
import { normalize } from '../Normalizer';
import { StyleSheet } from "react-native";
import { CommonActions } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";

const Profile = ({navigation}) => {
    const [edit,setEdit]=useState("");
    const [name, setName] = useState('');
    const [lastName, setLastName] = useState('');
    const [address, setAddress] = useState('');
    const [phonenumber, setphonenumber] = useState('');
    const [email, setEmail] = useState('');
    const [oldPassword, setOldPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [username,setusername]=useState('');
    
    
    useEffect(()=>{
        AsyncStorage.getItem('token').then((token)=>{
            if (token != null) {
              console.log("token",token);
              getCurrentUser(token)
            }
          })  })
    
    
    const getCurrentUser=(userToken)=>{
      
          
        console.log(userToken,"token in get user");
        axios.get('http://192.168.137.44:8000/current-user/', {
                  headers: { Authorization: `Token ${userToken}` }
              })
              .then(function (response) {
                  setRole(response.data.usertype);
                //   AsyncStorage.setItem('userRole',JSON.stringify(response.data.usertype));
                  setLoading(false);
                  navigation.navigate("Home");
              })
              .catch(function (error) {
                  console.log(error,"getuser");
              })
              .then(function () {
                  // always executed
              });
      }

    return(
    <ScrollView style={{flex:1}}>
        <View style={styles.container}>
            <View style={styles.body}>
                <Image
                    source={require("../assets/myamonn-icons/USER.png")}
                    style={{height:normalize(100),width:normalize(100)}}
                />
                <View style={styles.profileDescription}>
                    <Text style={styles.username}>
                        Huzaifa
                    </Text>
                    <Text style={styles.userType}>
                        USER TYPE
                    </Text>

                </View>
                {edit=="personal"?
                <TouchableOpacity 
                    onPress={()=>setEdit("")} 
                    style={styles.formBody}>
                <View style={styles.regForm}>
                    <Text style={[styles.editButtonText,{marginBottom:10}]}>
                        PERSONAL INFORMATION
                    </Text>
                    <View style={styles.twoInputView}>
                        <View style={styles.inputView}>
                            <TextInput
                                style={styles.TextInput}
                                placeholder="NAME"
                                placeholderTextColor={"white"}
                                value={name}
                                onChangeText={(name) => setName(name)}
                            />
                        </View>
                        <View style={styles.inputView}>
                            <TextInput
                                style={styles.TextInput}
                                placeholderTextColor={"white"}
                                placeholder={"LAST NAME"}
                                value={lastName}
                                onChangeText={(lastname) => setLastName(lastname)}
                            />
                        </View>
                    </View>
                    <View style={[styles.inputView,{width:normalize(338),alignSelf:"center"}]}>
                        <TextInput
                            editable={false}
                            style={styles.TextInput}
                            placeholder="EMAIL"
                            placeholderTextColor={"white"}
                            value={email}
                            onChangeText={(email) => setEmail(email)}
                        />
                    </View>
                    <View style={[styles.inputView,{width:normalize(338),alignSelf:"center"}]}>
                        <TextInput
                            style={styles.TextInput}
                            placeholder="ADDRESS"
                            placeholderTextColor={"white"}
                            value={address}
                            onChangeText={(address) => setAddress(address)}
                        />
                    </View>
                    <View style={styles.twoInputView}>
                        <View style={styles.inputView}>
                            <TextInput
                                style={styles.TextInput}
                                placeholder="PHONE NUMBER"
                                placeholderTextColor={"white"}
                                value={phonenumber}
                                onChangeText={(phonenumber) => setphonenumber(phonenumber)}
                            />
                        </View>
                    </View>
                    <View style={{justifyContent:"flex-end",alignItems:"flex-end"}}>
                        <TouchableOpacity
                            onPress={()=>{
                                setEdit("")}}
                            style={{
                                backgroundColor:"black",
                                justifyContent:"center",
                                alignItems:"center",
                                width:normalize(63),
                                height:normalize(40,735),
                                borderRadius:25}}>
                            <Text style={{color:"white",fontFamily:"OpenSansCondensedBold",fontSize:normalize(14)}}>SAVE</Text>
                        </TouchableOpacity>
                    </View>
                </View>
                </TouchableOpacity>
                :
                <TouchableOpacity 
                    style={styles.editButton}
                    onPress={()=>{
                        setEdit("personal")}
                    }
                >
                    <Text style={styles.editButtonText}>PERSONAL INFORMATION
                    </Text>
                    <Image source={require("../assets/myamonn-icons/edit-red.png")}/>
                </TouchableOpacity>}
                {edit=="password"?
                <TouchableOpacity 
                    onPress={()=>setEdit("")}
                    style={styles.formBody}>
                <View style={styles.regForm}>
                    <Text style={[styles.editButtonText,{marginBottom:10}]}>
                        CHANGE PASSWORD
                    </Text>
                    
                    <View style={[styles.inputView,{width:normalize(338),alignSelf:"center"}]}>
                        <TextInput
                            secureTextEntry={true}
                            style={styles.TextInput}
                            placeholder="ACTUAL PASSWORD"
                            placeholderTextColor={"white"}
                            onChangeText={(oldpassword) => setOldPassword(oldpassword)}
                        />
                    </View>
                    <View style={[styles.inputView,{width:normalize(338),alignSelf:"center"}]}>
                        <TextInput
                            secureTextEntry={true}
                            style={styles.TextInput}
                            placeholder="NEW PASSWORD"
                            placeholderTextColor={"white"}
                            onChangeText={(newpassword) => setNewPassword(newpassword)}
                        />
                    </View>
                    <View style={{justifyContent:"flex-end",alignItems:"flex-end"}}>
                        <TouchableOpacity 
                            onPress={()=>{
                                setEdit("")}}
                            style={{
                                backgroundColor:"black",
                                justifyContent:"center",
                                alignItems:"center",
                                width:normalize(63),
                                height:normalize(40,735),
                                borderRadius:25}}>
                            <Text style={{color:"white",fontFamily:"OpenSansCondensedBold",fontSize:normalize(14)}}>SAVE</Text>
                        </TouchableOpacity>
                    </View>
                </View>
                </TouchableOpacity>

                :<TouchableOpacity 
                    style={styles.editButton}
                    onPress={()=>setEdit("password")}
                    >
                    <Text style={styles.editButtonText}>CHANGE PASSWORD</Text>
                    <Image source={require("../assets/myamonn-icons/edit-red.png")}/>
                </TouchableOpacity>}

            </View>
            
            <TouchableOpacity style={styles.loginBtn}
                onPress={()=>{
                    navigation.navigate("Login",{action:"logout"});
                }}
            >
                <Text style={styles.loginText}>{"Logout"}</Text>
            </TouchableOpacity>
        </View>
        </ScrollView>
    )
}

export default Profile;
const styles = StyleSheet.create({
    container:{
        flex:1,
        justifyContent:"space-between",
        alignItems:"center",
        height:normalize(600,735),
        marginTop:normalize(100),
    },
    profileDescription:{
        height:normalize(40,735),
        justifyContent:"space-evenly",
        alignItems:"center"
    },
    username:{
        color:"black",
        fontFamily:"OpenSansCondensedBold",
        fontSize:normalize(16),
    },
    userType:{
        color:"black",
        fontFamily:"OpenSansCondensedLight",
        fontSize:normalize(14),
    },
    body:{
        justifyContent:"space-evenly",
        alignItems:"center",
    },
    editButton:{
        elevation:20,
        flexDirection:"row",
        backgroundColor:"white",
        height:normalize(46,735),
        width:normalize(376),
        justifyContent:"space-between",
        alignItems:"center",
        paddingHorizontal:normalize(19),
        borderRadius:35,
        marginTop:normalize(25,735)
    },
    editButtonText:{
        color:"#333333",
        fontFamily:"OpenSansCondensedBold",
        fontSize:normalize(16),
    },
    contact:{
        color:"black",
        fontFamily:"OpenSansCondensedBold",
        fontSize:normalize(13),
        textAlign:"center"
    },
    formBody:{
        elevation:30,
        width:normalize(376),
        height:normalize(300,735),
        marginTop:normalize(25,735),
        borderRadius:41,
        backgroundColor:"white",
        justifyContent:"center",
        alignItems:"center"
    },
    regForm:{
        width:normalize(338),
    },
    inputView: {
        backgroundColor:"grey",
        borderRadius: normalize(30),
        height: normalize(40),
        width:normalize(164),
        justifyContent:"center",
        marginBottom:normalize(10,735)
    },
    TextInput: {
        width: "100%",
        height: "100%",
        paddingLeft: normalize(20),
        fontFamily:"OpenSansCondensedBold",
        color:"#FFFFFF",
        fontSize:normalize(14),
    },
    twoInputView:{
        flexDirection:"row",
        justifyContent:"space-between",
    },
    activityIndicatorStyle: {
        flex: 1,
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
      },
})